set targetDir to system attribute "TARGET"
tell application "System Events" to tell process "Tableau"
set itemsToExport to {{"04 - Occupancy Trend", "occupancy"}, {"05 - Waiting Time Trend", "waiting"}, {"06 - Patient Acuity Mix", "acuity"}, {"07 - External Triggers", "triggers"}, {"08 - Surge Risk Monitoring", "surge"}}
repeat with job in itemsToExport
set {sheetTitle, filename} to contents of job
 if filename is not "occupancy" then
click menu item sheetTitle of menu 1 of menu bar item "Window" of menu bar 1
delay 0.45
click menu bar item "Worksheet" of menu bar 1
click menu item "Image..." of menu 1 of menu item "Export" of menu 1 of menu bar item "Worksheet" of menu bar 1
delay 0.5
key code 36
end if
delay 0.45
keystroke "g" using {command down, shift down}
delay 0.35
keystroke targetDir
key code 36
delay 0.45
set value of text field "Save As:" of splitter group 1 of window "Save Image" to "tableau-" & filename
click button "Save" of splitter group 1 of window "Save Image"
delay 0.5
end repeat
end tell
