from pathlib import Path
import pymupdf as pdf

W = Path('work')
original = pdf.open(Path.home() / 'Downloads' / 'RMP - PRM ANALYSIS.pdf')
doc = pdf.open()
doc.insert_pdf(original, from_page=0, to_page=2)
fonts_dir = Path('/System/Library/Fonts/Supplemental')
paths = {
    'TNR': fonts_dir / 'Times New Roman.ttf',
    'TNRB': fonts_dir / 'Times New Roman Bold.ttf',
    'TNRI': fonts_dir / 'Times New Roman Italic.ttf',
    'Cal': Path('/Applications/Microsoft Word.app/Contents/Resources/DFonts/Calibri.ttf'),
}
fonts = {key: pdf.Font(fontfile=str(path)) for key, path in paths.items()}
left, right, center = 72.024, 526.3, 299.475

def put(page, x, y, content, face='TNR', size=12, align='left', color=(0, 0, 0)):
    length = fonts[face].text_length(content, fontsize=size)
    x -= length * {'left': 0, 'center': .5, 'right': 1}[align]
    page.insert_font(fontname=face, fontfile=str(paths[face]))
    page.insert_text((x, y), content, fontname=face, fontsize=size, color=color)

def clear(page, *rects):
    for rect in rects:
        page.add_redact_annot(rect, fill=False)
    page.apply_redactions(images=0, graphics=0)

def wrap(content, face, size, width):
    lines, current = [], ''
    for word in content.split():
        combined = ' '.join(filter(None, (current, word)))
        if current and fonts[face].text_length(combined, fontsize=size) > width:
            lines.append(current)
            current = word
        else:
            current = combined
    return lines + [current]

def paragraph(page, content, y, face='TNR', leading=15.88, gap=8, x=left, justify=True):
    lines = wrap(content, face, 12, right-x)
    for index, line in enumerate(lines):
        if justify and index < len(lines)-1 and len(line.split()) > 2:
            # Adjust PDF word spacing while preserving the searchable text as a single line.
            width = fonts[face].text_length(line, fontsize=12)
            page.insert_font(fontname=face, fontfile=str(paths[face]))
            before = set(page.get_contents())
            page.insert_text((x,y), line, fontname=face, fontsize=12)
            stream = next(iter(set(page.get_contents())-before))
            # Embedded Times New Roman is a composite font, so use TJ adjustments
            # between words instead of the PDF word-spacing operator.
            import re
            data = doc.xref_stream(stream)
            match = re.search(rb'\[<([0-9a-fA-F]+)>\]TJ', data)
            if match:
                glyphs = match[1]
                space = f'{fonts[face].has_glyph(32):04x}'.encode()
                encoded = [glyphs[i:i+4] for i in range(0,len(glyphs),4)]
                adjustment = round(-(right-x-width)/(len(line.split())-1)/12*1000, 3)
                parts, chunk = [], b''
                for glyph in encoded:
                    chunk += glyph
                    if glyph.lower() == space:
                        parts.extend((b'<' + chunk + b'>', str(adjustment).encode()))
                        chunk = b''
                if chunk:
                    parts.append(b'<'+chunk+b'>')
                doc.update_stream(stream,data[:match.start()]+b'['+b' '.join(parts)+b']TJ'+data[match.end():])
        else:
            put(page, x, y, line, face)
        y += leading
    return y + gap

def table(page, y):
    data = [
        ('Field group', 'Fields and interpretation'),
        ('Time and capacity', 'Hour, BedsOccupied and TotalBeds. Capacity is fixed at 100.'),
        ('Waiting time', 'RollingWaitMin records the hourly rolling wait in minutes.'),
        ('Patient acuity', 'Level1Count through Level5Count record counts for five triage levels.'),
        ('External conditions', 'StadiumEventFlag, TrafficIncidentCount and SeasonalFluIndex describe event status, traffic and flu context.'),
    ]
    x = [left, 195, 521.62]
    top = y - 10
    for row, (label, meaning) in enumerate(data):
        face = 'TNRB' if row == 0 else 'TNR'
        lines = wrap(meaning, face, 12, x[2]-x[1]-13)
        height = max(28, 15.88*len(lines) + 10)
        page.draw_rect((x[0], top, x[2], top+height), width=.48)
        page.draw_line((x[1], top), (x[1], top+height), width=.48)
        put(page, x[0]+6, top+15, label, face)
        for i, line in enumerate(lines):
            put(page, x[1]+6, top+15+15.88*i, line, face)
        top += height
    return top+26

def comparison_table(page, y, widths, rows):
    top = y - 10
    x = left
    for width, column in zip(widths, zip(*rows)):
        for i, value in enumerate(column):
            row_top = top + i * 31
            page.draw_rect((x, row_top, x + width, row_top + 31), width=.48)
            put(page, x + width / 2, row_top + 19.5, value,
                'TNRB' if i == 0 else 'TNR', align='center')
        x += width
    return top + 31 * len(rows) + 27

def render(page, content, y, leading=15.88, justify=True):
    for line in content.strip().splitlines():
        if not line:
            continue
        if line.startswith('# '):
            y = paragraph(page,line[2:],y,'TNRB',leading,8,justify=False)
        elif line.startswith('!'):
            name, caption = line[1:].split('|',1)
            source = W/f'browser-{name}.png'
            picture = pdf.Pixmap(source)
            ratio = picture.height / picture.width
            width = min(450.25, 445/ratio)
            height = width*ratio
            top = y-4
            page.insert_image((center-width/2, top, center+width/2, top+height), filename=str(source))
            put(page, center, top+height+16, caption, 'TNRI', align='center')
            y = top+height+43
        elif line == '@dataset':
            y = table(page,y)
        elif line == '@periods':
            y = comparison_table(page, y, (88, 92, 85, 91, 93), [
                ('Time window', 'Avg. occupancy', 'Avg. wait', 'Traffic incidents', 'Triage count'),
                ('00:00–05:59', '38.0%', '15.8 min', '0', '99'),
                ('06:00–11:59', '50.8%', '24.7 min', '3', '136'),
                ('12:00–15:59', '64.0%', '35.3 min', '4', '115'),
                ('16:00–18:59', '73.7%', '48.0 min', '9', '106'),
                ('19:00–23:59', '87.0%', '75.8 min', '15', '220'),
            ])
        elif line == '@components':
            y = comparison_table(page, y, (62, 84, 72, 72, 72, 87), [
                ('Hour', 'Occupancy', 'Wait', 'Event', 'Traffic', 'Total score'),
                ('15:00', '0.268', '0.148', '0.000', '0.010', '0.426'),
                ('16:00', '0.276', '0.159', '0.150', '0.020', '0.605'),
                ('18:00', '0.316', '0.218', '0.150', '0.040', '0.724'),
                ('21:00', '0.364', '0.327', '0.000', '0.030', '0.721'),
            ])
        elif line == '@acuity_breakdown':
            y = comparison_table(page, y, (160, 90, 94, 105), [
                ('Triage level', 'Daily count', '23:00 count', '23:00 share'),
                ('Resuscitation (Critical)', '50', '4', '10.0%'),
                ('Emergency (High)', '96', '7', '17.5%'),
                ('Urgent', '183', '11', '27.5%'),
                ('Less Urgent', '256', '14', '35.0%'),
                ('Non-Urgent', '91', '4', '10.0%'),
            ])
        elif line.startswith('$'):
            url = line[1:]
            put(page, 90, y-8, url)
            page.insert_link({'kind':pdf.LINK_URI,'from':pdf.Rect(90,y-20,90+fonts['TNR'].text_length(url,fontsize=12),y-4),'uri':url})
            y += 8
        elif line.startswith('**Keywords:** '):
            label = 'Keywords: '
            put(page,left,y,label,'TNRB')
            start=left+fonts['TNRB'].text_length(label,fontsize=12)
            line='Emergency room operations, Tableau, bed occupancy, waiting time,'
            put(page,start,y,line)
            put(page,left,y+leading,'patient acuity, surge risk.')
            y+=2*leading
        else:
            y = paragraph(page,line,y,leading=leading,x=90 if line[:2] in [str(i)+'.' for i in range(1,10)] else left,justify=justify)
    assert y < 771, (page.number, y)
    return y

cover=doc[0]
clear(cover,(90,56,509,79),(90,94,509,114),(90,191,509,259),
      (90,302,509,347),(90,740,509,760))
cover.draw_rect((24.72,24.72,570.72,817.32),width=1.44)
put(cover,center,73.56,'ER CAPACITY PULSE','TNRB',18,'center')
put(cover,center,108.86,'21IPE313P – Interactive Data Visualization Techniques and Analysis','TNR',14.04,'center')
put(cover,center,205.34,'MUKUL PARASHAR (RA2311027010008)','TNRB',14.04,'center')
put(cover,center,229.46,'LINGAM GAURAV KUMAR (RA2311027010006)','TNRB',14.04,'center')
put(cover,center,253.58,'KRISHNA LODHA(RA2311056010095)','TNRB',14.04,'center')
put(cover,center,317.93,'Dr. Jeba Sonia J (102863)','TNRB',14.04,'center')
put(cover,center,342.17,'(Associate Professor, Department of Data Science and Business Systems)','TNRI',14.04,'center')
put(cover,center,755.50,'NOVEMBER – 2026','TNRB',14.04,'center')

abstract,*chapters = (part.strip() for part in (W/'report.txt').read_text().split('\n===\n'))
abstract_title, abstract_content = abstract.split('\n',1)
page=doc[1]
clear(page,(61,84,545,773))
y=paragraph(page,abstract_title,100.10,'TNRB',20.68,8,justify=False)
render(page,abstract_content,y,20.68)

starts=[]
page_number=0
titles=[]
for chapter_no, chapter in enumerate(chapters,1):
    title, content = chapter.split('\n',1)
    titles.append(title)
    starts.append(page_number+1)
    for section_no, section in enumerate(content.split('\n---\n')):
        page_number += 1
        doc.insert_pdf(original,from_page=3,to_page=3)
        page=doc[-1]
        clear(page,(55,40,543,762),(460,780,537,794))
        page.draw_rect((70.45,778.15,525,778.95), color=None, fill=(1,1,1))
        put(page,523.42,790.176,str(page_number),'Cal',11.04,'right')
        y=69.84
        if section_no==0:
            heading = f'CHAPTER {chapter_no}: {title}' if chapter_no < 8 else title
            for line in wrap(heading,'TNRB',14.04,right-left):
                put(page,center,y,line,'TNRB',14.04,'center')
                y+=19.45
            y+=5.18
        render(page,section,y,justify=chapter_no<8)

toc=doc[2]
rows=[198.14,249.02,299.21,350.09,400.97,451.15,501.31,551.47]
clear(toc,*[(471,y-13,515,y+4) for y in rows])
for y,page_number in zip(rows,starts):
    put(toc,492.63,y,str(page_number),'TNR',12,'center')
for row, pnum in enumerate(starts):
    toc.insert_link({'kind':pdf.LINK_GOTO,'from':pdf.Rect(139,rows[row]-19,520,rows[row]+19),'page':pnum+2,'to':pdf.Point(0,0)})
doc.set_toc([[1,'Abstract',2],[1,'Table of Contents',3]]+
    [[1,f'{i}. {t.title()}' if i<8 else 'References',n+3] for i,(t,n) in enumerate(zip(titles,starts),1)])
doc.set_metadata(dict(title='ER Capacity Pulse',author='Mukul Parashar, Lingam Gaurav Kumar, Krishna Lodha',subject='21IPE313P – Interactive Data Visualization Techniques and Analysis'))
doc.save('outputs/ER Capacity Pulse - Case Study Report.pdf',garbage=4,deflate=True)
print('Chapter start pages:',starts,'Total PDF pages:',len(doc))
