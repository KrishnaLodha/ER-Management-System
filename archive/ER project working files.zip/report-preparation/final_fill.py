from pathlib import Path
path=Path('work/report.txt')
s=path.read_text()
revisions=[
("This check gives a reproducible way to tell whether a pie chart is using the daily view or a selected hour.",
"""This check gives a reproducible way to tell whether a pie chart is using the daily view or a selected hour.

Keep the same hour selection when comparing the source and the workbook. Switching the acuity view back to all hours should restore the daily denominator of 676."""),
("Using the pivoted traffic bar value of 20 in a manual calculation would overstate the traffic contribution and could produce an incorrect severity label.",
"""Using the pivoted traffic bar value of 20 in a manual calculation would overstate the traffic contribution and could produce an incorrect severity label.

Keep the full-precision score for the severity calculation. A dashboard can display three decimal places while retaining the exact value to distinguish observations near a threshold."""),
("It does not establish how much an additional occupied bed would change wait time.",
"""It does not establish how much an additional occupied bed would change wait time.

The median hourly wait was 32 minutes, compared with the mean of 37.8. The median describes the middle hourly reading, while the higher mean reflects the influence of the longer evening waits."""),
("A tooltip that shows the score components would let a reviewer see this difference without reconstructing the calculation from four separate charts.",
"""A tooltip that shows the score components would let a reviewer see this difference without reconstructing the calculation from four separate charts.

A second way to read the result is to compare each peak with the critical threshold. The 18:00 and 21:00 scores are about 0.026 and 0.029 below 0.75, respectively. The narrow gap describes how close the demonstration came to the configured cutoff. The cutoff itself remains a design choice that requires validation on more than one day.

The score also changes by different amounts before and after the flag switches off. From 18:00 to 19:00, the score drops by about 0.069 even as occupancy and wait rise. Comparing the components explains why the line dips while the underlying demand indicators continue to climb."""),
("Recording both the current values and their change since the previous check gives the incoming shift a reason to continue monitoring.",
"""Recording both the current values and their change since the previous check gives the incoming shift a reason to continue monitoring.

The receiving team can use the same hour selection to review the source indicators and agree when to check again. This makes the handover repeatable across shifts."""),
("Fix and recheck those issues before using the pilot log to evaluate the warning settings.",
"""Fix and recheck those issues before using the pilot log to evaluate the warning settings.

Where a warning was reviewed promptly, record whether the displayed indicators were enough to explain it or whether the reviewer had to open a separate worksheet."""),
("After correcting the worksheet, rerun the selected-hour check and the all-hours KPI check.",
"""After correcting the worksheet, rerun the selected-hour check and the all-hours KPI check.

Include a reset check after testing the filters. Clear the selected hour and confirm that both trend charts show all 24 hours and the acuity view returns to the daily total.""")
]
for old,new in revisions:
 assert s.count(old)==1
 s=s.replace(old,new)
a=s.index('# 7.3 Conclusion')
b=s.index('# 7.4 Evidence Needed for Future Validation')
c=s.index('\n===\nREFERENCES',b)
future=s[b:c].rstrip().replace('# 7.4 ', '# 7.3 ',1)
conclusion=s[a:b].rstrip().replace('# 7.3 ', '# 7.4 ',1)
extra="""The initial review should also report hours with missing values separately. That makes it possible to distinguish a missed warning from a period when the dashboard lacked the readings it needed to produce a score."""
s=s[:a]+future+'\n\n'+extra+'\n'+conclusion+s[c:]
path.write_text(s)
