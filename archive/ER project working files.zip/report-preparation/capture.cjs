const { chromium } = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
(async () => {
 const browser = await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try {
  const page=await browser.newPage({viewport:{width:1600,height:1800},deviceScaleFactor:2});
  const figures=['dashboard','occupancy','waiting','acuity','triggers','surge'];
  for (const figure of figures) {
   const source='tableau-'+figure+'.png';
   if (!fs.existsSync(path.join(__dirname,source))) throw Error('Missing '+source);
   const heights={dashboard:2800,occupancy:1285,waiting:1284,acuity:1190,triggers:1285,surge:1330};
   const widths={dashboard:3200,occupancy:1602,waiting:1392,acuity:2166,triggers:1498,surge:1386};
   const scale=Math.min(0.5,1550/widths[figure]);
   const file=path.join(__dirname,'figure-'+figure+'.html');
   fs.writeFileSync(file,`<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#fff}figure{margin:0;overflow:hidden;width:${widths[figure]*scale}px;height:${heights[figure]*scale}px}img{display:block;width:100%;height:auto}</style><figure><img alt="Tableau ${figure} export" src="${source}"></figure>`);
   await page.goto(pathToFileURL(file).href);
   const chart=page.locator('img');
   await chart.evaluate(img=>img.decode());
   await page.locator("figure").screenshot({path:path.join(__dirname,'browser-'+figure+'.png')});
  }
 } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1});
