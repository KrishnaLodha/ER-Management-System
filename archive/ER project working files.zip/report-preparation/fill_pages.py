from pathlib import Path
report=Path('work/report.txt')
chapters=[s.strip() for s in report.read_text().split('\n===\n')]
sections=[s.split('\n---\n') for s in chapters]
additions={
(1,0):"""# 1.5 How the Report Reads the Dashboard
The analysis follows three questions a shift team might ask. How busy is the department now? How quickly are conditions changing? What else was happening as demand rose? The occupancy and wait views address the first two questions. The triage mix and external indicators help put those trends in context.""",
(2,0):"""# 2.3.1 Preserving the Level of Each Measure
The hourly source works as a single record of capacity and demand at each time point. A separate triage table would contain the hour, triage category and count. Both tables could share an hour key. If a future dataset contains several days or sites, the key should also include the date and site so that, for example, two different 21:00 readings remain distinct.

Keeping the tables separate makes the intended totals easier to check. An hourly bed value would appear once in the capacity view, while the acuity view could retain one value for each category.""",
(2,1):"""# 2.6 Reproducing the Daily Totals
Adding the hourly capacity values gives 2,400 available bed-hours on the same hourly basis. Dividing the sum of occupied-bed readings by that denominator gives 1,445 ÷ 2,400, or 60.2% rounded. The wait KPI comes from 907 minutes across 24 recorded hourly wait values, or 37.8 minutes. The 907 is a sum of hourly readings and serves as an intermediate calculation for the mean.

Triage counts can be checked separately by adding the five category totals. The dataset contains 50 resuscitation, 96 emergency, 183 urgent, 256 less-urgent and 91 non-urgent counts. Together they give the 676 used as the denominator for the full-day pie chart. This check gives a reproducible way to tell whether a pie chart is using the daily view or a selected hour.""",
(3,0):"""# 3.3.1 Worked Example at 18:00
At 18:00, the CSV records 79 occupied beds, a 56-minute rolling wait, an active event flag and four traffic incidents. These values contribute 0.316 from occupancy, about 0.218 from wait, 0.150 from the event and 0.040 from traffic. Their sum is approximately 0.724, which falls in the Warning band.

Each input should be interpreted in its original units before it enters the formula. For example, the occupancy input is 0.79 and the traffic input is four incidents. Using the pivoted traffic bar value of 20 in a manual calculation would overstate the traffic contribution and could produce an incorrect severity label.""",
(3,1):"""# 3.5 Reading the Views Together
The KPI cards provide a baseline for the day. The hourly charts show when conditions departed from that baseline. Reading the occupancy and wait charts along the same hour labels helps a reviewer compare the timing of changes, while the surge plot shows when the combined score reaches a warning band.

The colour encodings have distinct meanings. Orange on the event-sensitive charts marks the stadium flag, while orange on the surge chart marks Warning. The legends and axis labels identify which meaning applies to each view.""",
(4,0):"""At the peak, nine of the 100 beds were unoccupied in the demo. The preceding five-hour stretch shows the pressure building: occupancy rose from 69% at 16:00 to 91% at 21:00. Occupancy stayed above 80% for the final five observations, so the peak was part of a sustained period of high utilisation.""",
(4,1):"""The largest hour-to-hour increase was 12 minutes, from 56 at 18:00 to 68 at 19:00. The rolling wait stayed above 60 minutes for the remaining five observations. Comparing consecutive hours makes this acceleration visible even though the daily average was below 40 minutes.""",
(4,2):"""@acuity_breakdown""",
(4,3):"""The timing also differs across the indicators. The traffic count peaks at 19:00, two hours before the occupancy and wait peaks, while the flu index holds at 0.40 for six consecutive readings. These patterns are best read as context for the hourly demand charts. Each measure describes a different condition.""",
(4,4):"""Of the 24 observations, 16 fall in Normal and eight in Warning. The final score is about 0.610. It remains above 0.50 even after occupancy and wait begin to fall, so the plotted day ends while the warning is still active.""",
(4,5):"""Across all 24 observations, occupancy and rolling wait have a Pearson correlation of about 0.97. Both generally rise over the day and peak together. Since the observations come from one time series, this value describes how closely the two measures moved on the demonstration day. It does not establish how much an additional occupied bed would change wait time.""",
(4,6):"""The difference between the observed peaks at 18:00 and 21:00 is only about 0.003. Both belong to the same warning band, but at 21:00 occupancy and wait alone contribute about 0.691. At 18:00 those two terms total about 0.534. A tooltip that shows the score components would let a reviewer see this difference without reconstructing the calculation from four separate charts.""",
(5,0):"""# 5.4 Example Shift Handover
At 16:00, a shift lead reviewing the demonstration would see 69% occupancy, a 41-minute rolling wait and a score of 0.605. The active event flag explains much of the change in the score. The handover could record that context and identify who will review the next reading.

At 19:00, the event flag has cleared but the score remains in Warning. The relevant update is now the combination of 85% occupancy, a 68-minute wait and five traffic incidents. Recording both the current values and their change since the previous check gives the incoming shift a reason to continue monitoring.""",
(6,0):"""# 6.3.1 Recording Pilot Results
A pilot log can record the time of each warning, the active filters, the score and the observed conditions. It can also record who reviewed the warning and when the review took place. This makes it possible to separate delays in the dashboard feed from delays in the review process.

At the end of the pilot, compare the log with the hourly source. Identify cases where the dashboard and the source differed, then group them by cause, such as a delayed refresh, an inconsistent filter or an aggregation error. Fix and recheck those issues before using the pilot log to evaluate the warning settings.""",
(6,1):"""# 6.5 Documenting a Test Run
For a reproducible test, save the workbook version and the date of the source file with the results. Record the selection that produced each view. For example, a screenshot of an acuity chart should show whether a specific hour or the full day was selected. This makes it possible for a second reviewer to repeat the same check.

A failed check should identify the worksheet, expected reading and value observed. If the dashboard reports 455 occupied beds at 21:00, for instance, record 91 as the expected value and trace the difference to the sum over the five pivot rows. After correcting the worksheet, rerun the selected-hour check and the all-hours KPI check.""",
(7,0):"""# 7.4 Evidence Needed for Future Validation
A longer dataset would allow the team to define periods of sustained pressure independently of the surge score and compare those periods with the alerts. It would also show whether lead time and the frequency of false alerts differ by shift or event status. The team would need to specify the evaluation period and the criteria for a useful alert before adjusting the thresholds.

The same review should confirm whether the 90-minute wait scale and the traffic scale of 10 remain suitable for the data being monitored. New settings can then be evaluated on a separate set of days so that performance reflects more than the conditions used to choose the weights.""",
}
for (chapter,section),extra in additions.items():
    sections[chapter][section]+='\n\n'+extra
report.write_text('\n===\n'.join('\n---\n'.join(chapter) for chapter in sections)+'\n')
