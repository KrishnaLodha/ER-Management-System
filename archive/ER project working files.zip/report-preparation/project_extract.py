import zipfile,pathlib,re,xml.etree.ElementTree as E
h=pathlib.Path.home()/'Downloads'
z=zipfile.ZipFile(h/'ER_Capacity_Pulse.pptx')
for n in z.namelist():
 if re.fullmatch('ppt/slides/slide[0-9]+.xml',n):
  print(n,' '.join(t.text or '' for t in E.fromstring(z.read(n)).iter('{http://schemas.openxmlformats.org/drawingml/2006/main}t')))
 if n.endswith('.png') and 'ppt/media/' in n: (pathlib.Path('work')/n.split('/')[-1]).write_bytes(z.read(n))
r=E.parse(h/'Tableau.twb')
for x in r.iter('thumbnail'):print(x.attrib,len(x.text or ''))
for x in r.findall('./datasources/datasource/column'):
 if x.find('calculation') is not None:print(x.get('caption'),x.find('calculation').get('formula'))
