import Cocoa
import ApplicationServices
func attr(_ x:AXUIElement,_ k:String)->AnyObject?{var v:CFTypeRef?; if AXUIElementCopyAttributeValue(x,k as CFString,&v) == .success {return v}; return nil}
func walk(_ x:AXUIElement,_ n:Int) {
 if n>8{return}
 let role=attr(x,"AXRole") as? String ?? ""
 for k in ["AXTitle","AXValue","AXDescription"]{
  if let s=attr(x,k) as? String,!s.isEmpty{print(role,k,s)}
 }
 for y in attr(x,"AXChildren") as? [AXUIElement] ?? []{walk(y,n+1)}
}
let app=AXUIElementCreateApplication(Int32(CommandLine.arguments[1])!)
for w in attr(app,"AXWindows") as? [AXUIElement] ?? [] {walk(w,0)}
