import Cocoa
import ApplicationServices
func attr(_ x:AXUIElement,_ k:String)->AnyObject?{var v:CFTypeRef?; if AXUIElementCopyAttributeValue(x,k as CFString,&v) == .success {return v}; return nil}
func walk(_ x:AXUIElement,_ n:Int)->[AXUIElement] {
 if n>8{return []}
 return [x]+(attr(x,"AXChildren") as? [AXUIElement] ?? []).flatMap{walk($0,n+1)}
}
let a=CommandLine.arguments
let app=AXUIElementCreateApplication(Int32(a[1])!)
let els=(attr(app,"AXWindows") as? [AXUIElement] ?? []).flatMap{walk($0,0)}
let hits=els.filter{(attr($0,"AXTitle") as? String)==a[2] && (attr($0,"AXRole") as? String)=="AXButton"}
if let hit=(a.count>3 ? hits.last : hits.first) {print(AXUIElementPerformAction(hit,kAXPressAction as CFString).rawValue)}
