from pathlib import Path
import csv
import pymupdf as pdf
W=Path(__file__).resolve().parent
out=W.parent.parent/'outputs'
reference=pdf.open(out/'ER Capacity Pulse - Case Study Report.pdf')
doc=pdf.open()
doc.insert_pdf(reference,from_page=0,to_page=0)
fonts_path=Path('/System/Library/Fonts/Supplemental')
paths={'R':fonts_path/'Times New Roman.ttf','B':fonts_path/'Times New Roman Bold.ttf','I':fonts_path/'Times New Roman Italic.ttf'}
fonts={k:pdf.Font(fontfile=str(v)) for k,v in paths.items()}
L,R,C=72,523.5,297.66
def put(p,x,y,s,face='R',size=12,align='left',color=(0,0,0)):
    width=fonts[face].text_length(s,fontsize=size)
    x-=width*{'left':0,'center':.5,'right':1}[align]
    p.insert_font(fontname='TT'+face,fontfile=str(paths[face]))
    p.insert_text((x,y),s,fontname='TT'+face,fontsize=size,color=color)
def wrap(s,width=R-L,face='R',size=12):
    lines=[]; current=''
    for word in s.split():
        new=(current+' '+word).strip()
        if current and fonts[face].text_length(new,fontsize=size)>width:
            lines.append(current); current=word
        else: current=new
    return lines+[current]
cover=doc[0]
cover.add_redact_annot((130,55,468,81),fill=False)
cover.apply_redactions(images=0,graphics=0)
put(cover,C,73.56,'ER CAPACITY PULSE','B',18,'center')
put(cover,C,91,'Case 2: Emergency Room Surge','B',12,'center')
put(cover,C,155,'Team No. __________','R',11,'center')
cover.add_redact_annot((120,407,478,427),fill=False)
cover.apply_redactions(images=0,graphics=0)
put(cover,C,422.57,'COMPUTER SCIENCE ENGINEERING','B',14.04,'center')
nav=[]
class Page:
    def __init__(self,title):
        self.p=doc.new_page(width=595.32,height=841.92)
        self.p.draw_rect((24.72,24.72,570.72,817.32),width=1.44)
        self.y=70
        for line in wrap(title,face='B',size=14.04):
            put(self.p,C,self.y,line,'B',14.04,'center'); self.y+=19
        self.y+=9
        put(self.p,R,790,str(len(doc)-1),size=11,align='right')
        nav.append([1,title,len(doc)])
    def para(self,s,face='R',size=12,leading=17,gap=10):
        for line in wrap(s,face=face,size=size):
            put(self.p,L,self.y,line,face,size)
            self.y+=leading
        self.y+=gap
        assert self.y<775,(self.p.number,self.y,s)
    def head(self,s): self.para(s,'B',12,16,5)
    def table(self,widths,rows,sz=11):
        y=self.y-10
        for i,row in enumerate(rows):
            face='B' if i==0 else 'R'
            cells=[wrap(str(v),w-14,face,sz) for w,v in zip(widths,row)]
            ht=max(24,14*max(map(len,cells))+12)
            x=L
            for w,lines in zip(widths,cells):
                self.p.draw_rect((x,y,x+w,y+ht),width=.45)
                for j,t in enumerate(lines):
                    put(self.p,x+7,y+14+j*14,t,face,sz)
                x+=w
            y+=ht
        self.y=y+22
        assert self.y<775,(self.p.number,self.y)
    def fig(self,name,caption,h):
        path=W/('browser-'+name+'.png')
        pic=pdf.Pixmap(path)
        w=min(R-L,h*pic.width/pic.height)
        h=w*pic.height/pic.width
        y=self.y-9
        self.p.insert_image((C-w/2,y,C+w/2,y+h),filename=str(path))
        self.y=y+h+17
        self.para(caption,'I',11,15,12)
    def link(self,label,url):
        width=fonts['R'].text_length(label,fontsize=11)
        put(self.p,L,self.y,label,size=11,color=(.12,.26,.4))
        self.p.insert_link({'kind':pdf.LINK_URI,'from':pdf.Rect(L,self.y-11,L+width,self.y+2),'uri':url})
        self.y+=18

p=Page('1. PROBLEM AND THE TWIST')
p.head('The decision facing the charge nurse')
p.para('A charge nurse needs enough time to prepare for a possible emergency room surge. If the team waits for bed occupancy to cross a high threshold, patients may already be waiting longer and the staffing decision becomes reactive. The purpose of this dashboard is to show what changed and give the charge nurse an earlier point at which to review coverage.')
p.head('The twist')
p.para('Bed occupancy is a lagging measure in this scenario. An evening stadium event and a rise in nearby traffic incidents can become visible before the main rise in waiting time. Staff still need to see why an alert fired. The dashboard therefore shows three individual inputs beside the surge score and keeps observed wait severity separate from the early alert.')
p.head('What the case study tests')
p.para('The replay compares an occupancy-only alert with an improved rule that uses event status, traffic incidents and Level 1 acuity. It measures the gap from the event start to the first defined wait rise, and the lead time of the improved alert relative to both that rise and the occupancy-only alert.')
p.head('Reading the two-day replay')
p.para('Day 1 contains the planted stadium event and subsequent surge. Day 2 is a synthetic comparison day with no stadium event and lighter demand. Hours 0–23 represent Day 1, and hours 24–47 represent Day 2. All observations are demonstration data, and the notification routes are proposals for the exercise.')
p.table([120,331],[('Question','Evidence in this report'),('Did wait rise after the event?','Colour-coded hourly wait and a measured event-to-rise delay.'),('Would the early rule buy time?','First-trigger comparison with the occupancy-only rule.'),('Can a nurse explain the warning?','Three visible inputs, a comparison KPI and a separate routing table.')])

with (W/'ER Case 2 Hourly Demo.csv').open() as f:
 rows=list(csv.reader(f))[1:]
p=Page('2. DATASET')
p.para('The submitted CSV contains 48 rows, seven fields and one observation per hour. Hour is the chronological replay key. Day 2 clock time is Hour − 24, so Hour 24 represents Day 2 at 00:00.')
p.table([145,306],[('Field','Meaning'),('Hour','Elapsed hour, 0–47.'),('BedsOccupied','Occupied beds at the hourly reading.'),('TotalBeds','Available capacity, fixed at 100 beds.'),('RollingWaitMin','Rolling wait measure in minutes at that hour.'),('AcuityLevel1Count','Count of Level 1 presentations in that hour.'),('StadiumEventFlag','1 while the stadium event is active, otherwise 0.'),('TrafficIncidents','Number of reported traffic incidents in that hour.')])
p.head('First 10 source rows')
p.table([47,66,61,75,66,66,70],[('Hour','Occupied','Total beds','Wait (min)','Level 1','Event flag','Traffic')]+[tuple(row) for row in rows[:10]],10.5)
p.para('Column headings in the sample are shortened for print. The accompanying CSV uses the full field names listed above.',size=11)

p=Page('3. DATA BUILD AND CHECKS')
p.para('Day 1 reuses the original ER project’s occupancy, capacity, acuity, event and traffic data. For the Case 2 exercise, the 16:00 and 17:00 wait values were set to 38 and 39 minutes. The 18:00 wait remained 56 minutes, followed by 68 minutes at 19:00. This makes the delayed rise visible as a deliberate test case.')
p.para('Day 2 is a constructed comparison. Its occupied beds are round(0.70 × Day 1 beds + 10), and its wait is round(0.44 × adjusted Day 1 wait + 10). The event flag is zero, Level 1 counts are capped at two, and traffic incidents are capped at one. These assumptions create a quieter comparison day and are recorded so the data can be reproduced.')
p.head('Planted events')
p.table([117,116,218],[('What','Where','Why it was planted'),('Stadium event','Day 1, 16:00–18:00','Expose an outside signal before the main wait rise.'),('Traffic increases','Day 1, 16:00–19:00','Provide a second visible outside signal. Counts reach five at 19:00.'),('Delayed wait rise','Day 1, 18:00 onward','Test a rise two hours after event start and before the occupancy-only alert.'),('Quieter comparison','Day 2, all hours','Check behaviour on a day without a planted surge.')])
p.head('Checks performed')
p.para('The file has one unique row for every hour from 0 to 47, with 24 records per day and no missing values. All 48 rows have 100 beds. Occupied beds stay within capacity. Wait and count values are non-negative, and the event flag is 1 only at hours 16, 17 and 18. The revised source stays at one row per hour, so the workbook can aggregate hourly measures without the earlier triage pivot duplicating them.')

p=Page('4. METRIC DESIGN AND CALCULATIONS')
p.head('Capacity and waiting time')
p.para('Occupancy Rate = SUM([BedsOccupied]) / SUM([TotalBeds]). Format as a percentage. At Day 1 19:00 the result is 85 ÷ 100 = 85%. See Figure 2.')
p.para('Lower Wait Band = { FIXED : AVG([RollingWaitMin]) } − 2 × { FIXED : STDEV([RollingWaitMin]) }. Upper Wait Band = { FIXED : AVG([RollingWaitMin]) } + 2 × { FIXED : STDEV([RollingWaitMin]) }. STDEV is the sample standard deviation. Across 48 rows, the mean is 31.94 min and SD is 18.19 min. The bounds are −4.44 and 68.31 min. See Figure 3.')
p.para('Wait Severity = IF [RollingWaitMin] >= 75 THEN "Critical" ELSEIF [RollingWaitMin] >= 45 THEN "Warning" ELSE "Normal" END. The observed wait determines the tier. See Figure 4.')
p.head('Early warning and the replay card')
p.para('Surge Risk = [StadiumEventFlag] + INT([TrafficIncidents] >= 2) + INT([AcuityLevel1Count] >= 3). Each input adds one point when active. The result is a transparent count from 0 to 3, with all three raw inputs shown on the KPI card.')
p.para('Naive Alert = INT([BedsOccupied] / [TotalBeds] >= 0.85). Improved Alert = INT([Surge Risk] >= 2). One indicates that the rule is active for that hour. See Figure 5.')
p.para('Previous Hour Risk = { FIXED : MAX(IF [Hour] = 16 THEN [Surge Risk] END) }. This returns the 16:00 score for the 17:00 replay card. Risk Change = [Surge Risk] − [Previous Hour Risk].')
p.para('Trend Arrow = IF [Risk Change] > 0 THEN "↑" ELSEIF [Risk Change] < 0 THEN "↓" ELSE "→" END. The 17:00 card reads 3/3, up from 2/3 in the previous hour. See Figure 6.')
p.para('The 45- and 75-minute wait tiers, 85% occupancy cutoff, and early-rule input thresholds are demonstration settings. The statistical band provides context and is separate from the severity thresholds.', 'I', 11)

p=Page('5. DASHBOARD AND ALERTS')
p.para('The dashboard brings the three-input KPI, occupancy, event-coloured wait band, wait severity and both alert rules together. The charts share the same 0–47 replay-hour scale.')
p.fig('dashboard','Figure 1. Case 2 Tableau dashboard showing the two-day replay and the Day 1 17:00 KPI snapshot.',525)
p.para('The first 24 hours show the planted Day 1 pattern. Hours 24–47 show the quieter comparison day. The score card exposes its inputs separately so the viewer can check the reason for the signal.')

p=Page('5. DASHBOARD AND ALERTS · CAPACITY AND WAIT')
p.fig('occupancy','Figure 2. Hourly occupancy rate. Day 1 19:00 reaches 85%, the occupancy-only alert threshold.',224)
p.fig('band','Figure 3a. Rolling wait with a mean ± 2 sample SD band. Orange bars are the stadium-event hours.',250)
p.fig('detail','Figure 3b. Enlarged view of the event window. Wait first jumps at Hour 18.',130)
p.para('The wait is 38 minutes at the 16:00 event start, 39 at 17:00 and 56 at 18:00. Define the surge onset as the first rise of at least 10 minutes from the preceding hour after the event starts. The 18:00 reading rises by 17 minutes, so the measured delay is 18:00 − 16:00 = 2 hours.')
p.para('At 19:00, three hours after the event starts, wait rises another 12 minutes to 68. The band uses all 48 hourly waits. Its negative lower bound is a mathematical reference, while actual waiting times are non-negative.')

p=Page('5. DASHBOARD AND ALERTS · SEVERITY AND TRIGGERS')
p.fig('severity','Figure 4. Hourly wait severity. Orange is Normal, red is Warning, and blue is Critical, as shown in the legend.',220)
p.fig('naive','Figure 5a. Naive alert activity. The first active hour is 19:00.',190)
p.fig('improved','Figure 5b. Improved alert activity. The first active hour is 16:00.',190)
p.table([121,110,110,110],[('Rule','First active','Active hours','Lead vs naive'),('Naive occupancy','Day 1, 19:00','4','Baseline'),('Improved surge','Day 1, 16:00','7','3 hours')])
p.para('The improved rule first fires at Day 1 16:00. The naive rule first fires at 19:00, yielding three hours of lead time. The improved rule is also two hours ahead of the defined wait-rise onset at 18:00.')
p.para('Normal covers 40 of the 48 readings, Warning covers five and Critical covers three. The first Warning is at 18:00 (56 minutes) and the first Critical is at 20:00 (78 minutes). These are observed wait tiers, separate from the improved alert.')

p=Page('5. DASHBOARD AND ALERTS · KPI AND ROUTING')
p.fig('kpi','Figure 6. Surge Risk KPI at Day 1 17:00. The arrow and prior-hour value show the comparison, and the three raw inputs explain the score.',175)
p.para('At 17:00, the event is active, traffic is three and Level 1 acuity is three, giving 3/3. At 16:00 the event and traffic conditions were active while Level 1 acuity was two, so the prior score was 2/3.')
p.head('Proposed notification routing')
p.table([84,115,130,122],[('Tier','Who is told','Channel','Expected action'),('Normal','Charge nurse','Dashboard and routine handover','Continue scheduled monitoring.'),('Warning','Charge nurse and staffing coordinator','Secure unit message with an acknowledgement request','Review the drivers and identify backup coverage.'),('Critical','Charge nurse, ED shift lead and hospital flow or staffing supervisor','Immediate call or pager with confirmation','Escalate promptly under the hospital’s approved procedure.')])
p.para('A Critical reading means the rolling wait has reached at least 75 minutes, so it requires faster delivery, confirmation and a broader response than Warning. An improved alert during Normal wait severity prompts an early staffing review through the Warning channel. It leaves the observed wait tier unchanged.')

p=Page('6. FINDINGS AND STAFFING RECOMMENDATION')
p.table([93,112,246],[('Day 1 time','Signal','Reading and interpretation'),('16:00','External leads','Event starts and traffic reaches two. Improved alert activates while occupancy is 69% and wait is 38 minutes.'),('17:00','Acuity context','Level 1 count reaches three. The score rises from 2/3 to 3/3 before the defined wait rise.'),('18:00','Wait response','Wait rises from 39 to 56 minutes. Occupancy is 79%, still below the naive threshold.'),('19:00','Occupancy lags','Occupancy reaches 85% and the naive alert fires. Wait is already 68 minutes.'),('20:00','Critical wait','Wait reaches 78 minutes, activating the Critical routing tier.')])
p.head('Leading and lagging signals')
p.para('In this replay, the stadium flag and traffic reaching two incidents are leading signals because they are visible at 16:00, two hours before the measured wait rise. Traffic remains elevated after the rise, so its timing matters. Level 1 acuity adds internal demand context at 17:00. Rolling wait and occupancy describe pressure already being experienced. The 85% occupancy threshold is reached after the wait enters Warning.')
p.head('When to review staffing')
p.para('At 16:00, have the charge nurse verify the event and traffic readings and review backup coverage with the staffing coordinator. At 17:00, recheck the alert as acuity adds a third signal. At 18:00, the observed wait is in Warning and the unit should reassess coverage. If the Critical tier is reached, use the immediate route in the table.')
p.para('The improved rule is active for seven hours on Day 1, compared with four for the naive rule. Neither fires on the constructed Day 2. This is a replay comparison and does not estimate a false-alarm rate for a real hospital.')

p=Page('7. LIMITS AND CONCLUSION')
p.head('Limitations')
p.para('The dataset is synthetic and the Day 1 wait rise is deliberately planted. Day 2 is a quieter scenario derived from the same template. The observed delay therefore illustrates the test design. It cannot establish the effect of a stadium event on a real emergency department.')
p.para('Hourly readings can miss changes within an hour, and the dataset has no staffing roster, arrivals ledger or patient-level wait records. The same two days are used to illustrate the rules and describe the results. Historical data covering several event and non-event days would be needed to assess alert reliability and review thresholds.')
p.head('Conclusion')
p.para('The planted wait surge began two hours after the stadium event started.',gap=0)
p.para('The improved alert flagged risk three hours before the occupancy-only rule.',gap=0)
p.para('Visible inputs and separate wait tiers support an explainable staffing review.')
p.head('Team contribution')
p.table([133,318],[('Team member','Assigned contribution'),('Mukul Parashar','Data construction, planted events and validation checks.'),('Lingam Gaurav Kumar','Tableau calculations, dashboard views and alert comparison.'),('Krishna Lodha','Delay analysis, staffing recommendation, routing and report assembly.')])
p.head('Sources')
p.para('Course handout, Case 2. Supplied ER project CSV and Tableau workbook. Revised 48-row case-study dataset and Tableau workbook.',size=11,leading=15,gap=4)
p.link('Tableau Help · Reference Lines, Bands, Distributions, and Boxes','https://help.tableau.com/current/pro/desktop/en-us/reference_lines.htm')
p.link('Tableau Help · Create Custom Fields with Calculations','https://help.tableau.com/current/pro/desktop/en-us/calculations_calculatedfields.htm')
doc.set_toc(nav)
doc.set_metadata(dict(title='ER Capacity Pulse - Case 2',author='Mukul Parashar, Lingam Gaurav Kumar, Krishna Lodha',subject='21IPE313P'))
doc.save(out/'ER Capacity Pulse - Case 2 Report.pdf',garbage=4,deflate=True)
print('Report pages:',len(doc))
