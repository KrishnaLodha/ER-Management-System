from pathlib import Path
import csv, statistics, json, uuid, copy
import xml.etree.ElementTree as E
W=Path(__file__).parent.resolve()
H=Path.home()/'Downloads'
NAME='ER Case 2 Hourly Demo.csv'
fields=['Hour','BedsOccupied','TotalBeds','RollingWaitMin','AcuityLevel1Count','StadiumEventFlag','TrafficIncidents']
with (H/'ER_Capacity_Pulse_Extended_Demo_Dataset.csv').open() as f:
 source=list(csv.DictReader(f))
day1=[[int(r[k]) for k in ['Hour','BedsOccupied','TotalBeds','RollingWaitMin','Level1Count','StadiumEventFlag','TrafficIncidentCount']] for r in source]
day1[16][3]=38
day1[17][3]=39
day2=[]
for h,occ,cap,wait,acuity,event,traffic in day1:
 day2.append([h+24,round(0.70*occ+10),cap,round(0.44*wait+10),min(2,acuity),0,min(1,traffic)])
rows=day1+day2
with (W/NAME).open('w',newline='') as f:
 w=csv.writer(f); w.writerow(fields); w.writerows(rows)
def score(r): return r[5]+int(r[6]>=2)+int(r[4]>=3)
waits=[r[3] for r in rows]; avg=statistics.mean(waits); sd=statistics.stdev(waits)
print('mean, sd, bounds',avg,sd,avg-2*sd,avg+2*sd)
print('alerts', [r[0] for r in rows if score(r)>=2],[r[0] for r in rows if r[1]/r[2]>=.85])
print('tiers',*[sum(low<=v<high for v in waits) for low,high in [(0,45),(45,75),(75,1000)]])
ds='federated.168pa66184sxn41gveiy61bzznyb'
conn='textscan.0rfka5d1q8u8kw1av331u19ohiy9'
root=E.Element('workbook',{'original-version':'18.1','source-platform':'mac','source-build':'2026.2.1 (20262.26.0819.2015)','version':'18.1'})
def add(node,tag,txt=None,**attrs):
 child=E.SubElement(node,tag,{k.replace('_','-'):str(v) for k,v in attrs.items()})
 child.text=txt
 return child
def uid(): return '{'+str(uuid.uuid4()).upper()+'}'
template=E.parse(H/'Tableau.twb').getroot()
root.set('xmlns:user','http://www.tableausoftware.com/xml/user')
root.insert(0,copy.deepcopy(template.find('document-format-change-manifest')))
root.insert(1,copy.deepcopy(template.find('preferences')))
source_node=add(add(root,'datasources'),'datasource',caption='ER Case 2 Hourly Demo',inline='true',name=ds,version='18.1')
connection=add(source_node,'connection',**{'class':'federated'})
named=add(add(connection,'named-connections'),'named-connection',caption='ER Case 2 Hourly Demo',name=conn)
add(named,'connection',**{'class':'textscan','directory':str(W),'filename':NAME,'password':'','server':''})
rel=add(connection,'relation',connection=conn,name=NAME,table='[ER Case 2 Hourly Demo#csv]',type='table')
columns=add(rel,'columns',character_set='UTF-8',header='yes',locale='en_US',separator=',')
for i,k in enumerate(fields): add(columns,'column',datatype='integer',name=k,ordinal=i)
add(source_node,'aliases',enabled='yes')
raw_specs={
 'Hour':('Hour','dimension','ordinal'),
 'StadiumEventFlag':('Stadium event','dimension','ordinal'),
 'BedsOccupied':('Beds occupied','measure','quantitative'),
 'TotalBeds':('Total beds','measure','quantitative'),
 'RollingWaitMin':('Rolling wait (min)','measure','quantitative'),
 'AcuityLevel1Count':('Level 1 acuity count','measure','quantitative'),
 'TrafficIncidents':('Traffic incidents','measure','quantitative'),
}
calc_specs={
 'Occ':('Occupancy Rate','real','measure','quantitative','SUM([BedsOccupied]) / SUM([TotalBeds])'),
 'WaitLow':('Lower Wait Band','real','measure','quantitative','{ FIXED : AVG([RollingWaitMin]) } - 2 * { FIXED : STDEV([RollingWaitMin]) }'),
 'WaitHigh':('Upper Wait Band','real','measure','quantitative','{ FIXED : AVG([RollingWaitMin]) } + 2 * { FIXED : STDEV([RollingWaitMin]) }'),
 'WaitTier':('Wait Severity','string','dimension','nominal','IF [RollingWaitMin] >= 75 THEN "Critical" ELSEIF [RollingWaitMin] >= 45 THEN "Warning" ELSE "Normal" END'),
 'Risk':('Surge Risk','integer','measure','quantitative','[StadiumEventFlag] + INT([TrafficIncidents] >= 2) + INT([AcuityLevel1Count] >= 3)'),
 'Naive':('Naive Alert','integer','measure','quantitative','INT([BedsOccupied] / [TotalBeds] >= 0.85)'),
 'Early':('Improved Alert','integer','measure','quantitative','INT([Calculation_Risk] >= 2)'),
 'Prev':('Previous Hour Risk','integer','measure','quantitative','{ FIXED : MAX(IF [Hour] = 16 THEN [Calculation_Risk] END) }'),
 'Delta':('Risk Change','integer','measure','quantitative','[Calculation_Risk] - [Calculation_Prev]'),
 'Arrow':('Trend Arrow','string','dimension','nominal','IF [Calculation_Delta] > 0 THEN "↑" ELSEIF [Calculation_Delta] < 0 THEN "↓" ELSE "→" END'),
}
defs={}
for k,(caption,role,type_) in raw_specs.items():
 defs[k]=add(source_node,'column',caption=caption,datatype='integer',name=f'[{k}]',role=role,type=type_)
 if k=='StadiumEventFlag':
  aliases=add(defs[k],'aliases')
  for a,b in [(0,'No event'),(1,'Stadium event')]: add(aliases,'alias',key=a,value=b)
for k,(caption,datatype,role,type_,formula) in calc_specs.items():
 attr={'default_format':'p0%'} if k=='Occ' else {}
 defs[k]=add(source_node,'column',caption=caption,datatype=datatype,name=f'[Calculation_{k}]',role=role,type=type_,**attr)
 add(defs[k],'calculation',**{'class':'tableau','formula':formula})
styles=add(add(source_node,'style'),'style-rule',element='mark')
for key,ref,values in [('StadiumEventFlag','[none:StadiumEventFlag:ok]',[(0,'#4e79a7'),(1,'#e88722')]),('WaitTier','[none:Calculation_WaitTier:nk]',[('"Normal"','#478761'),('"Warning"','#df951c'),('"Critical"','#c63a42')])]:
 enc=add(styles,'encoding',attr='color',field=ref,type='palette')
 for value,color in values: add(add(enc,'map',to=color),'bucket',str(value))
worksheets=add(root,'worksheets')
sheets={}
def new_sheet(name):
 sheet=add(worksheets,'worksheet',name=name)
 add(add(add(add(sheet,'layout-options'),'title'),'formatted-text'),'run',name,bold='true',fontsize='16',fontname='Arial')
 table=add(sheet,'table')
 view=add(table,'view')
 add(add(view,'datasources'),'datasource',caption='ER Case 2 Hourly Demo',name=ds)
 deps=add(view,'datasource-dependencies',datasource=ds)
 style=add(table,'style')
 pane=add(add(table,'panes'),'pane',selection_relaxation_option='selection-relaxation-allow')
 add(add(pane,'view'),'breakdown',value='auto')
 add(sheet,'simple-id',uuid=uid())
 sheets[name]=(sheet,table,view,deps,style,pane)
 return sheets[name]
def instances(ctx, specs):
 _,table,view,deps,style,pane=ctx
 for defn in defs.values(): deps.append(copy.deepcopy(defn))
 refs={}
 for key, deriv, suffix in specs:
  field=defs[key].get('name')[1:-1]
  tag={'None':'none','Avg':'avg','User':'usr','Sum':'sum','Min':'min','Max':'max','Attribute':'attr'}[deriv]
  inst=f'[{tag}:{field}:{suffix}]'
  type_={'qk':'quantitative','ok':'ordinal','nk':'nominal'}[suffix]
  add(deps,'column-instance',column=f'[{field}]',derivation=deriv,name=inst,pivot='key',type=type_)
  refs[key]=f'[{ds}].{inst}'
 return refs
def chart(name,key,deriv,mark='Bar',color=None,band=False):
 ctx=new_sheet(name)
 _,table,view,_,style,pane=ctx
 specs=[('Hour','None','ok'),(key,deriv,'qk')]
 if color: specs.append((color,'None','ok' if color=='StadiumEventFlag' else 'nk'))
 if band: specs.extend([('WaitLow','Avg','qk'),('WaitHigh','Avg','qk')])
 ref=instances(ctx,specs)
 add(view,'aggregation',value='true')
 add(pane,'mark',**{'class':mark})
 if color: add(add(pane,'encodings'),'color',column=ref[color])
 if band:
  rule=add(style,'style-rule',element='refband')
  for k,v in [('fill-color','#eaf1f8'),('line-visibility','on'),('line-pattern-only','dashed'),('stroke-color','#496985')]:
   add(rule,'format',attr=k,id='waitband',value=v)
  r=add(pane,'reference-line',axis_column=ref[key],formula='stdev',id='waitband',scope='per-table',type='sample',z_order=1,enable_instant_analytics='true',value_column=ref[key],label_type='none')
  for n in (-2,2):add(r,'reference-line-value',factor=n)
 if key=='Occ':
  add(add(style,'style-rule',element='axis'),'format',attr='text-format',field=ref[key],value='p0%')
 if key in ('Naive','Early'):
  add(add(add(pane,'style'),'style-rule',element='mark'),'format',attr='mark-color',value='#64748b' if key=='Naive' else '#bf541f')
 add(table,'rows',ref[key])
 add(table,'cols',ref['Hour'])
 return ref
occ='01 Occupancy rate'
band='02 Rolling wait and event hours'
tier='03 Wait severity'
naive='04 Naive occupancy alert'
early='05 Improved surge alert'
card='06 Surge Risk KPI'
chart(occ,'Occ','User','Line')
band_ref=chart(band,'RollingWaitMin','Avg',color='StadiumEventFlag',band=True)
tier_ref=chart(tier,'RollingWaitMin','Avg',color='WaitTier')
chart(naive,'Naive','Max')
chart(early,'Early','Max')
ctx=new_sheet(card)
_,table,view,_,style,pane=ctx
ref=instances(ctx,[('Hour','None','ok'),('Risk','Max','qk'),('Delta','Max','qk'),('Prev','Max','qk'),('Arrow','Attribute','nk'),('StadiumEventFlag','Max','qk'),('TrafficIncidents','Max','qk'),('AcuityLevel1Count','Max','qk')])
flt=add(view,'filter',**{'class':'categorical','column':ref['Hour']})
add(flt,'groupfilter',function='member',level='[none:Hour:ok]',member='17')
add(view,'aggregation',value='true')
add(pane,'mark',**{'class':'Text'})
enc=add(pane,'encodings')
for k in ('Risk','Delta','Prev','Arrow','StadiumEventFlag','TrafficIncidents','AcuityLevel1Count'):
 add(enc,'text',column=ref[k])
label=add(add(pane,'customized-label'),'formatted-text')
def run(s,sz=16,bold=False):add(label,'run',s,fontsize=sz,bold=str(bold).lower(),fontname='Arial',fontcolor='#19354a')
def value(k,sz=16):run('<',sz,True);run(ref[k],sz,True);run('>',sz,True)
run('DAY 1  •  17:00 REPLAY SNAPSHOT\n',14,True)
value('Risk',26);run(' / 3  ',26,True);value('Arrow',26);run('  vs prior hour: ',17);value('Prev',17);run(' / 3\n',17)
run('Stadium event: ');value('StadiumEventFlag');run('    |    Traffic incidents: ');value('TrafficIncidents');run('    |    Level 1 acuity: ');value('AcuityLevel1Count')
pane_style=add(pane,'style')
rule=add(pane_style,'style-rule',element='cell')
add(rule,'format',attr='text-align',value='center')
add(rule,'format',attr='vertical-align',value='center')
add(add(pane_style,'style-rule',element='mark'),'format',attr='mark-labels-show',value='true')
add(table,'rows')
add(table,'cols')
dash_name='ER Capacity Pulse - Case 2'
dash=add(add(root,'dashboards'),'dashboard',name=dash_name,enable_sort_zone_taborder='true')
add(add(add(add(dash,'layout-options'),'title'),'formatted-text'),'run','ER CAPACITY PULSE  |  TWO-DAY SURGE REPLAY',bold='true',fontsize=19,fontcolor='#19354a')
add(dash,'style')
add(dash,'size',maxheight=1240,minheight=1240,maxwidth=1600,minwidth=1600,sizing_mode='fixed')
add(add(dash,'datasources'),'datasource',caption='ER Case 2 Hourly Demo',name=ds)
base=add(add(dash,'zones'),'zone',id=1,x=0,y=0,w=100000,h=100000,type_v2='layout-basic')
def zone(i,x,y,w,h,**attrs):
 z=add(base,'zone',id=i,x=x,y=y,w=w,h=h,**attrs)
 add(add(z,'zone-style'),'format',attr='margin',value='5')
 return z
zone(2,0,0,100000,5000,type_v2='title')
zone(3,0,5000,100000,13500,name=card)
zone(4,0,18500,100000,20000,name=occ)
zone(5,0,38500,88000,23000,name=band)
zone(6,88000,38500,12000,23000,name=band,type_v2='color',param=band_ref['StadiumEventFlag'],pane_specification_id=0)
zone(7,0,61500,88000,20500,name=tier)
zone(8,88000,61500,12000,20500,name=tier,type_v2='color',param=tier_ref['WaitTier'],pane_specification_id=0)
zone(9,0,82000,50000,18000,name=naive)
zone(10,50000,82000,50000,18000,name=early)
add(dash,'simple-id',uuid=uid())
windows=add(root,'windows',source_height=1000)
for name in sheets:
 win=add(windows,'window',**{'class':'worksheet','name':name})
 cards=add(win,'cards')
 strip=add(add(cards,'edge',name='right'),'strip',size=160)
 if name in (band,tier):
  colorref=band_ref['StadiumEventFlag'] if name==band else tier_ref['WaitTier']
  add(strip,'card',pane_specification_id=0,type='color',param=colorref)
 add(add(win,'viewpoint'),'zoom',type='entire-view')
 add(win,'simple-id',uuid=uid())
win=add(windows,'window',**{'class':'dashboard','name':dash_name,'maximized':'true'})
viewpoints=add(win,'viewpoints')
for name in sheets:add(add(viewpoints,'viewpoint',name=name),'zoom',type='entire-view')
add(win,'simple-id',uuid=uid())
win.insert(1,E.Element('active',{'id':'-1'}))
E.indent(root)
xml=E.tostring(root,encoding='utf-8')
(W/'ER Capacity Pulse - Case 2.twb').write_bytes(b"<?xml version='1.0' encoding='utf-8' ?>\n<!-- build 20262.26.0819.2015 -->\n"+xml)
