const { chromium }=require('playwright');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 try{
  const tab=await browser.newPage({viewport:{width:1750,height:1550},deviceScaleFactor:2});
  const figures={
   dashboard:[0,0,1600,1240], occupancy:[0,238,1600,240],
   band:[0,483,1600,282], severity:[0,771,1600,249],
   naive:[0,1024,800,216], improved:[800,1024,800,216], kpi:[485,113,630,104],
   detail:[442,521,410,230]
  };
  for(const [name,[x,y,w,h]] of Object.entries(figures)){
   const html=path.join(__dirname,'capture-'+name+'.html');
   fs.writeFileSync(html,`<!doctype html><meta charset="utf-8"><style>body{margin:0;background:white}figure{position:relative;overflow:hidden;margin:0;width:${w}px;height:${h}px}img{position:absolute;left:-${x}px;top:-${y}px;width:1600px;height:1240px}</style><figure><img alt="Tableau ${name} export" src="../case2-dashboard.png"></figure>`);
   await tab.goto(pathToFileURL(html).href);
   await tab.locator('img').evaluate(img=>img.decode());
   await tab.locator('figure').screenshot({path:path.join(__dirname,'browser-'+name+'.png')});
  }
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
