from io import BytesIO
from pathlib import Path

import pypdfium2 as pdfium
from PIL import Image
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE
from docx.shared import Emu, Pt

root = Path.cwd()
source = root / 'outputs' / 'ER Capacity Pulse - Case 2 Report.pdf'
destination = source.with_suffix('.docx')
pdf = pdfium.PdfDocument(source)
doc = Document()
doc.core_properties.title = 'ER Capacity Pulse – Case 2 Report'
doc.core_properties.author = 'Mukul Parashar, Lingam Gaurav Kumar, Krishna Lodha'
section = doc.sections[0]
width, height = pdf[0].get_size()
section.page_width = Emu(round(width * 20) * 635)
section.page_height = Emu(round(height * 20) * 635)
section.left_margin = section.right_margin = Pt(0)
section.top_margin = section.bottom_margin = Pt(0)
section.header_distance = section.footer_distance = Pt(0)
compression = OxmlElement('w:doNotAutoCompressPictures')
doc.settings.element.insert_element_before(compression, 'w:forceUpgrade', 'w:compat', 'w:rsids')

def element(tag, **attributes):
    obj = OxmlElement(tag)
    for name, value in attributes.items():
        obj.set(name, str(value))
    return obj

def add_fixed_picture(paragraph, image, width_emu, height_emu, description):
    run = paragraph.add_run()
    picture = run.add_picture(image, width=Emu(width_emu), height=Emu(height_emu))
    inline = picture._inline
    anchor = element('wp:anchor', distT=0, distB=0, distL=0, distR=0,
                     simplePos=0, relativeHeight=0, behindDoc=0, locked=1,
                     layoutInCell=1, allowOverlap=1)
    anchor.append(element('wp:simplePos', x=0, y=0))
    for direction in ('H', 'V'):
        position = element('wp:position' + direction, relativeFrom='page')
        offset = element('wp:posOffset')
        offset.text = '0'
        position.append(offset)
        anchor.append(position)
    anchor.append(inline.extent)
    anchor.append(element('wp:wrapNone'))
    inline.docPr.set('descr', description)
    anchor.append(inline.docPr)
    anchor.append(inline.find(qn('wp:cNvGraphicFramePr')))
    anchor.append(inline.graphic)
    inline.getparent().replace(inline, anchor)

for number, page in enumerate(pdf, start=1):
    paragraph = doc.add_paragraph()
    layout = paragraph.paragraph_format
    layout.page_break_before = number > 1
    layout.space_before = layout.space_after = Pt(0)
    layout.line_spacing = Pt(1)
    layout.keep_with_next = False
    layout.keep_together = False
    layout.widow_control = False
    bitmap = page.render(scale=300 / 72, fill_color=(255, 255, 255, 255), optimize_mode='print')
    image = BytesIO()
    bitmap.to_pil().convert('RGB').save(image, 'PNG', compress_level=6)
    image.seek(0)
    add_fixed_picture(paragraph, image, section.page_width, section.page_height,
                      f'ER Capacity Pulse report, PDF page {number} of {len(pdf)}.')

doc.save(destination)
print(destination)
