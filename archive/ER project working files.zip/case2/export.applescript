set targetDir to system attribute "TARGET"
tell application "System Events" to tell process "Tableau"
set frontmost to true
set jobs to {{"ER Capacity Pulse - Case 2","dashboard"},{"01 Occupancy rate","occupancy"},{"02 Rolling wait and event hours","band"},{"03 Wait severity","severity"},{"04 Naive occupancy alert","naive"},{"05 Improved surge alert","early"},{"06 Surge Risk KPI","kpi"}}
repeat with job in jobs
set {sheetTitle, filename} to contents of job
click menu item sheetTitle of menu 1 of menu bar item "Window" of menu bar 1
delay 0.55
if filename is "dashboard" then
click menu item "Export Image..." of menu 1 of menu bar item "Dashboard" of menu bar 1
else
click menu bar item "Worksheet" of menu bar 1
click menu item "Image..." of menu 1 of menu item "Export" of menu 1 of menu bar item "Worksheet" of menu bar 1
delay 0.45
key code 36
end if
delay 0.55
set exportName to "case2-" & filename
set value of text field 1 of splitter group 1 of window "Save Image" to exportName
click button "Save" of splitter group 1 of window "Save Image"
delay 0.55
log filename
end repeat
end tell
