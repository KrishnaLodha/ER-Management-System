from pathlib import Path
p=Path('work/case2/report.py')
s=p.read_text()
s=s.replace('nav=[]','''nav=[]
contents=doc.new_page(width=595.32,height=841.92)
contents.draw_rect((24.72,24.72,570.72,817.32),width=1.44)
put(contents,C,70,'TABLE OF CONTENTS','B',14.04,'center')''')
s=s.replace('str(len(doc)-1)','str(len(doc)-2)')
def before(anchor, addition):
    global s
    marker="\np=Page("+repr(anchor)+")"
    assert s.count(marker)==1,anchor
    s=s.replace(marker,'\n'+addition.rstrip()+'\n'+marker)
before('2. DATASET', """
p.head('What counts as a useful early warning?')
p.para('The warning should arrive while the charge nurse can still check coverage. It should also make clear whether the signal came from the event, traffic or acuity.')
""")
before('3. DATA BUILD AND CHECKS', """
p.para('The sample ends at Day 1 09:00. The event and comparison-day rows appear in the full CSV.',size=11,leading=14,gap=3)
""")
before('4. METRIC DESIGN AND CALCULATIONS', """
p.head('Keeping the replay reproducible')
p.para('The two changed Day 1 waits shape the onset of the example. Other Day 1 fields retain their source values. Day 2 is generated only after those wait changes, so the same transformation reproduces the submitted comparison rows.')
p.para('Hour is the key used to reconcile the CSV with the Tableau charts. An hour-to-hour comparison crosses the day boundary at Hour 24, while same-clock comparisons use pairs 24 hours apart.')
""")
before('5. DASHBOARD AND ALERTS', """
p.head('Using the calculations together')
p.para('The score counts conditions that are visible in the current row. A score of two can come from different combinations of inputs. The KPI shows the original values so the reviewer can identify which conditions contributed.')
p.para('The wait tier answers a separate question about present conditions. A Normal wait tier can appear alongside an improved alert, as it does at 16:00. That combination is the early-warning behaviour the case is designed to show.')

p=Page('4. METRIC DESIGN AND CALCULATIONS · VALIDATION')
p.para('The following checks reproduce values at specific hours from the 48-row CSV. The workbook results can be compared with these values by locating the same elapsed hour in the figures.')
p.table([103,153,195],[('Calculation','Inputs checked','Expected result'),('Occupancy at Hour 19','85 occupied out of 100','85%, the first reading to meet the naive threshold.'),('Wait bands','48 hourly values','Mean 31.94 min, sample SD 18.19 min, limits −4.44 and 68.31 min.'),('Wait severity','56 min at Hour 18 and 78 min at Hour 20','Warning at Hour 18 and Critical at Hour 20.'),('Score at Hour 16','Event = 1, traffic = 2, Level 1 = 2','2/3. The event and traffic tests pass.'),('Score at Hour 17','Event = 1, traffic = 3, Level 1 = 3','3/3. All three tests pass.'),('KPI comparison','Hour 17 score 3, Hour 16 score 2','Change of +1 and an upward arrow.')])
p.head('Checks at the cutoffs')
p.para('The rules include their thresholds. A wait of exactly 45 minutes is Warning, and exactly 75 minutes is Critical. Occupancy of exactly 85% activates the naive alert. A surge score of exactly two activates the improved alert. Checking equality prevents the rule from changing meaning at the boundary.')
p.head('Interpreting a reading beyond the band')
p.para('The upper band is 68.31 minutes, so the 68-minute wait at Hour 19 stays inside it. The 78-minute wait at Hour 20 exceeds it. The same reading is Critical under the separate 75-minute policy threshold. Agreement in this example does not make the statistical band a routing rule.')
""")
before('5. DASHBOARD AND ALERTS · CAPACITY AND WAIT', """
p.head('How to read the dashboard')
p.para('Start with the KPI card to see which inputs are active. Then read the occupancy and waiting-time views at the same hour. The event colour supplies timing context, while the separate wait-severity legend shows how serious the observed wait is under the exercise thresholds.')
p.para('The two alert panels use 1 for an active rule and 0 otherwise. The enlarged views on the following pages isolate the event window and the first active hours for print.')
""")
before('5. DASHBOARD AND ALERTS · SEVERITY AND TRIGGERS', """
p.table([109,109,105,128],[('Day 1 hour','Wait','Hourly change','Event status'),('16:00','38 min','0 min','Starts'),('17:00','39 min','+1 min','Active'),('18:00','56 min','+17 min','Active'),('19:00','68 min','+12 min','Cleared')])
""")
before('6. FINDINGS AND STAFFING RECOMMENDATION', """
p.head('What the acknowledgement should capture')
p.para('A short acknowledgement can record the replay hour, wait tier, active risk inputs and the person taking the next action. For Warning, record who will verify coverage and when the unit will check again. For Critical, record who received the call and whether the escalation was acknowledged.')
p.para('If the alert stays active across consecutive readings, retain the time of the first trigger and log any change in tier or responsibility. This preserves the lead-time calculation for later review.')

p=Page('5. DASHBOARD AND ALERTS · HOURLY REPLAY')
p.para('The table compares the two alert rules through the event window. The surge score uses one point per active condition, and the wait tier is calculated from the wait column alone.')
event_rows=[('Hour','Beds %','Wait','Event','Traffic','Level 1','Score','Naive','Early')]
for r in rows[15:24]:
    hour,bed,total,wait,acuity,stadium,traffic=map(int,r)
    score=stadium+int(traffic>=2)+int(acuity>=3)
    event_rows.append((f'{hour}:00',f'{bed/total:.0%}',wait,stadium,traffic,acuity,score,int(bed/total>=.85),int(score>=2)))
p.table([59,53,47,48,49,51,49,46,49],event_rows,10.5)
p.head('Three distinct points in the replay')
p.para('At 16:00, the improved alert is already active while wait is 38 minutes and occupancy is 69%. At 18:00 the wait increases sharply and enters Warning. At 19:00 the naive alert turns on. Treating these as separate events makes clear which rule offered the earlier opportunity to review staffing.')
p.head('Why the improved rule stays active after the event')
p.para('At 19:00 the event flag clears, but traffic remains at or above two and Level 1 acuity remains at or above three. Those two inputs keep the score at two through 22:00. At 23:00, traffic drops to one, so the improved alert clears even though wait remains at 70 minutes. The wait-based routing still applies.')
""")
before('7. LIMITS AND CONCLUSION', """
p.para('The comparison day illustrates another useful distinction. Its wait reaches Warning at 21:00 and 22:00, even though neither early rule fires. The wait tier therefore remains available as a direct response to observed pressure on an event-free day.')

p=Page('6. FINDINGS AND STAFFING RECOMMENDATION · PILOT CHECKS')
p.para('A pilot would first check that the source, worksheet and notification workflow agree. The demonstration values below provide test cases that reviewers can reproduce before discussing a live rollout.')
p.table([114,163,174],[('Check','Expected behaviour','Record for review'),('Early warning','At 16:00 the event and traffic flags activate the improved rule while observed wait stays Normal.','First alert time, two active inputs and the agreed next review time.'),('Observed Warning','At 18:00 the wait reaches 56 minutes.','Confirm the Warning message and the recipient’s acknowledgement.'),('Observed Critical','At 20:00 the wait reaches 78 minutes.','Confirm immediate routing and record who accepted the escalation.'),('Early signal clears','At 23:00 the risk score falls to one while the wait is still 70 minutes.','Confirm the wait tier remains Warning.'),('No-event day','No early alert fires on Day 2. Wait still enters Warning at two hours.','Log both hours as observed wait warnings rather than suppressing them.')])
p.head('How to evaluate the pilot')
p.para('For each replay or test day, record the first improved alert, first occupancy-only alert and first observed wait threshold crossing. Calculate the gaps using elapsed hours, and record missing readings separately. Report how often the warning was acknowledged and whether staff could identify its active inputs from the card.')
p.para('Use several event and non-event days to look for alerts that staff judge unhelpful and for pressure episodes missed by the early rule. Review these outcomes before proposing new thresholds. Two constructed days cannot provide reliable estimates of live performance.')
""")
s=s.replace("p.head('Conclusion')", """p.head('What additional data would help')
p.para('A future review could pair the hourly measures with actual staffed beds, arrival counts and timestamps for operational responses. This would help test whether an alert arrived early enough to inform a decision and whether the same thresholds behaved consistently across shifts.')
p.head('Conclusion')""")
s=s.replace('doc.set_toc(nav)', '''labels=[
 '1. Problem and the twist',
 '2. Dataset and first 10 rows',
 '3. Data build and checks',
 '4. Metric design and calculations',
 '4. Worked validation checks',
 '5. Tableau dashboard overview',
 '5. Capacity, wait and event delay',
 '5. Severity and alert comparison',
 '5. Surge KPI and notification routing',
 '5. Hourly replay of the alerts',
 '6. Findings and staffing recommendation',
 '6. Pilot checks',
 '7. Limits, conclusion, team contributions and sources',
]
assert len(labels)==len(nav)
toc=contents
top=121
x=[72.024,463.90,521.38]
for i,(label,target) in enumerate([('SECTION',None)]+list(zip(labels,[n[2] for n in nav]))):
    height=40 if i==0 else 43
    for a,b in zip(x,x[1:]): toc.draw_rect((a,top,b,top+height),width=.48)
    put(toc,x[0]+12,top+height/2+4,label,'B' if i==0 else 'R',12)
    put(toc,(x[1]+x[2])/2,top+height/2+4,'PAGE' if i==0 else str(target-2),'B' if i==0 else 'R',12,'center')
    if target is not None:
        toc.insert_link({'kind':pdf.LINK_GOTO,'from':pdf.Rect(x[0],top,x[2],top+height),'page':target-1,'to':pdf.Point(0,0)})
    top+=height
doc.set_toc([[1,'Table of contents',2]]+nav)''')
# Page objects are reloaded after subsequent page insertions.
s=s.replace('toc=contents','toc=doc[1]')
p.write_text(s)
